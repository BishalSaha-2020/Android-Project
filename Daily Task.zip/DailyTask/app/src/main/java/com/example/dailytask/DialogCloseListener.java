package com.example.dailytask;

public interface DialogCloseListener {
}
