# How to Create a Notification - Android Studio Tutorial
<img src="https://codingwithsara.com/wp-content/uploads/2020/08/notification-screenshot.png" width="540" height="auto">  
　  
   
## Tutorial Video
https://www.youtube.com/watch?v=F3IFF8A-ewE  
　  
   
## Environment
Android Studio 4.0.1  
Android Emulator Nexus 4(API 28)

minSdkVersion 15  
compileSdkVersion 29  
　  
   
## License
Licenced under the [MIT license](https://en.wikipedia.org/wiki/MIT_License).
